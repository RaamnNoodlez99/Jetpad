#ifndef SOLDIER_H
#define SOLDIER_H
#include <iostream>

#include "WarUtilities.h"

using namespace std;

class Soldier : public WarUtilities {
public:
    Soldier(string rank);
    ~Soldier();

    string getRank();
    double getProbability();
    void setProbability(double p);

private:
    string rank;
    double probability;

};

#endif