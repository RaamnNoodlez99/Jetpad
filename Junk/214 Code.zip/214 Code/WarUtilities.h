#ifndef WARUTILITIES_H
#define WARUTILITIES_H

#include <iostream>

using namespace std;

class WarUtilities {


protected:
    int HP;
};

#endif